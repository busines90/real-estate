<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>
      <div class="content">
         <h3>why choose us?</h3>
         <p>In the dynamic realm of real estate, finding the perfect property or selling your cherished home can be a daunting task. The digital era has transformed the way we explore, buy, and sell properties, and at the heart of this revolution lies our exceptional real estate website. With a myriad of options available, why choose us? We stand out as a beacon of reliability, efficiency, and innovation in the vast sea of real estate platforms. Let us take you on a journey to discover the unparalleled reasons that make us the ultimate choice for all your real estate needs.</p>
         <a href="contact.php" class="inline-btn">contact us</a>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- steps section starts  -->

<section class="steps">

   <h1 class="heading">3 simple steps</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/step-1.png" alt="">
         <h3>search property</h3>
         <p>Explore our extensive and diverse range of property listings. From residential homes, apartments, and condos to commercial spaces and land parcels, our platform offers a wide array of options tailored to different tastes and budgets.</p>
      </div>

      <div class="box">
         <img src="images/step-2.png" alt="">
         <h3>contact agents</h3>
         <p>Get access to comprehensive property details, including images, floor plans, amenities, and neighborhood information. We believe in providing you with all the necessary information to make an informed decision about your potential new home or investment.</p>
      </div>

      <div class="box">
         <img src="images/step-3.png" alt="">
         <h3>enjoy property</h3>
         <p>Stay up-to-date with real-time property listings and market trends. Our platform ensures that you receive instant notifications about new listings, price changes, and relevant market news, keeping you ahead in your property search.</p>
      </div>

   </div>

</section>

<!-- steps section ends -->

<!-- review section starts  -->

<section class="reviews">

   <h1 class="heading">client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <div class="user">
            <img src="images/pic-1.jpeg" alt="">
            <div>
               <h3>Arsath</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>"Exceptional service! The team at SRM Real Estate made my property search effortless. Their expertise and dedication stood out. I found my dream home, and the process was smooth. Highly recommended! Thank you for making my real estate experience fantastic!"</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-2.jpeg" alt="">
            <div>
               <h3>Aseem</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Outstanding experience! SRM Real Estate Agency went above and beyond to find me the perfect home. Their professionalism and attention to detail were remarkable. From the first visit to the final paperwork, they made the process seamless. I couldn't be happier with my new home. Highly recommended</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-3.jpeg" alt="">
            <div>
               <h3>Basith</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Incredible service! SRM Real Estate Agency made my property buying process a breeze. Their team was incredibly knowledgeable and supportive. They understood my needs and found me a home that exceeded my expectations. I'm grateful for their expertise and highly recommend them for anyone in search of their dream property.</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-4.jpeg" alt="">
            <div>
               <h3>Shaheel</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Remarkable experience!SRM Real Estate provided exceptional service from start to finish. Their team was responsive, professional, and incredibly helpful. They guided me through every step of the home-buying process, making it stress-free. I'm now a happy homeowner, all thanks to their expertise. Highly recommended for anyone seeking a smooth real estate journey!</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-5.jpeg" alt="">
            <div>
               <h3>Suhaib</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Fantastic service! it made my property search effortless. Their team was attentive, understanding my needs perfectly. They presented options that matched my preferences and budget. Thanks to their dedication, I found my dream home. I'm grateful for their expertise and highly recommend them to anyone in search of the perfect property.</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-6.jpeg" alt="">
            <div>
               <h3>Rijash</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star-half-alt"></i>
               </div>
            </div>
         </div>
         <p>Exceptional professionalism! Srm exceeded my expectations. Their team was not only knowledgeable but also genuinely caring, ensuring I found the right home. They navigated every detail seamlessly, making my property purchase smooth and stress-free. I'm immensely satisfied with their service and highly recommend them to anyone entering the real estate market.</p>
      </div>

   </div>

</section>

<!-- review section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>