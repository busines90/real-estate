<!-- footer section starts  -->

<footer class="footer">

   <section class="flex">

      <div class="box">
         <a href="tel:1234567890"><i class="fas fa-phone"></i><span>9750990856</span></a>
         <a href="mailto:EA2232251010212"><i class="fas fa-envelope"></i><span>EA2232251010212</span></a>
         <a href="mailto:bh1097@srmist.edu"><i class="fas fa-envelope"></i><span>bh1097@srmist.edu</span></a>
         <a href="#"><i class="fas fa-map-marker-alt"></i><span>chennai, india - 620020</span></a>
      </div>

      <div class="box">
         <a href="index.php"><span>Home</span></a>
         <a href="about.php"><span>About</span></a>
         <a href="contact.php"><span>Contact</span></a>
         <a href="listings.php"><span>All listings</span></a>
         <a href="saved.php"><span>Saved properties</span></a>
      </div>

      <div class="box">
         <a href="https://www.facebook.com/basith.ahmed.5648"><span>facebook</span><i class="fab fa-facebook-f"></i></a>
         <a href="https://linkedin.com/in/basithoffi/"><span>linkedin</span><i class="fab fa-linkedin"></i></a>
         <a href="https://www.instagram.com/basith.21/"><span>instagram</span><i class="fab fa-instagram"></i></a>

      </div>

   </section>

   <div class="credit">&copy; copyright @ <?= date('Y'); ?> by <span>Mr Basith Ahmed</span> | all rights reserved!</div>

</footer>

<!-- footer section ends -->